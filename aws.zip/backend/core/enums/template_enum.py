from enum import Enum


class TemplateEnum(Enum):
    REGISTER = 'register.html'
    RECOVERY = 'recovery.html'
    SPAM = 'spam.html'
