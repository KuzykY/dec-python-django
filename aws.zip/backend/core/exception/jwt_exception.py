class JwtException(Exception):
    pass